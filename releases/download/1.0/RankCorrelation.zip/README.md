# RankCorrelation
Provides rank correlation coefficient metrics Kendall tau and Spearman rho  for evaluating regression schemes in WEKA. The implementation is taken from the Fantail project: http://fantail.quansun.com/.
